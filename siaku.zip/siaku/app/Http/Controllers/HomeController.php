<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\user_menu;
use Illuminate\Support\Arr;

class HomeController extends Controller
{
    public function index()
    {
        /// mengambil data terakhir dan pagination 5 list
        $userMenu = User_menu::get();

        /// mengirimkan variabel $posts ke halaman views posts/index.blade.php
        /// include dengan number index
        return view('view_dashboard', compact('userMenu'));
    }
}
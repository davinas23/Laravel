<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;

class latihan1 extends Controller
{
    /**
     * Show the profile for a given user.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function biodata()
    {
         $data['status'] = array(
         'posisi' => 'Direktur',
    	'instansi' => 'PT OTW Kaya',
    	'warganegara' => 'Indonesia',
    	'agama' => 'Islam');
    	

    	$data['biodata'] = array('nama' => 'Davina', 
    	'kelas' => 'IK19B',
    	'umur' => '19tahun',
    	'hobi' => 'Membaca Novel');

    	$data['pengalaman'] = array('pt' => 'PT Untung',
    	'sertifikat' => 'PSPL');
    	

    	return view('latihan1', $data);
    }
}
<?php
namespace App\Helpers;

use illuminate\Support\Facades\DB;

class General_helper {
	public static function getMenu(){
		
		$GLOBALS['user_group_id'] = 1;



		$getMenu = DB::table('users_menus')
			->select('user_menus.id', 'user_menus.parent_id', 'user_menus.name', 'user_menus.url', 'user_menus.icon_menu')
			->leftJoin('user_rules', 'user_menus.id', '=', 'user_rules.menu_id')
			->where('user_rules.group_id',$GLOBALS['user_group_id'])
			->where('user_menus.show_in_menu',1)
			->get();

		return General_helper::sotMenu($gerMenu);
	}

	public static function sortMenu($row, $parent_id = 0){
		// var_dump($row);
		//die;
		$return = array();

			foreach($raw as $key)
			{
				$proceed = FALSE;
				if($key->parent_id == $parent_id)
				{
				 $return = $raw;
				 $procceed = TRUE;
				}
				if($procceed) $return->child = General_helper::sotMenu($raw,
					$key->id);
			}
		return $return;
	}
}
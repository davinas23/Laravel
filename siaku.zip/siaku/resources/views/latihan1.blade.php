<html>
	<body>
			<h1>Assalamualaikum, Nama saya {{ $biodata['nama'] }}</h1>
		<p>Saya berasal dari kelas {{ $biodata['kelas'] }}</p>
		<p>Umur saya  {{ $biodata['umur'] }}</p>
		<p>Hobi saya adalah {{ $biodata['hobi'] }}</p>
			<h2> Status</h2>
		<p>Saya Sebagai {{ $status['posisi'] }} di {{ $status['instansi'] }}</p>
		<p>Sebagai warga negara {{ $status['warganegara'] }}</p>
		<p>Dan beragama {{ $status['agama'] }}</p>
			<h3>Pengalaman</h3>
		<p>Saya pernah bekerja di {{ $pengalaman['pt'] }}</p>
		<p>Memiliki sertifikat {{ $pengalaman['sertifikat'] }}</p>
	</body>
</html>
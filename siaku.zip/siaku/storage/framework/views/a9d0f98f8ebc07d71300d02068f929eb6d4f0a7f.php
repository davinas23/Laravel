<html>
	<body>
			<h1>Assalamualaikum, Nama saya <?php echo e($biodata['nama']); ?></h1>
		<p>Saya berasal dari kelas <?php echo e($biodata['kelas']); ?></p>
		<p>Umur saya  <?php echo e($biodata['umur']); ?></p>
		<p>Hobi saya adalah <?php echo e($biodata['hobi']); ?></p>
			<h2> Status</h2>
		<p>Saya Sebagai <?php echo e($status['posisi']); ?> di <?php echo e($status['instansi']); ?></p>
		<p>Sebagai warga negara <?php echo e($status['warganegara']); ?></p>
		<p>Dan beragama <?php echo e($status['agama']); ?></p>
			<h3>Pengalaman</h3>
		<p>Saya pernah bekerja di <?php echo e($pengalaman['pt']); ?></p>
		<p>Memiliki sertifikat <?php echo e($pengalaman['sertifikat']); ?></p>
	</body>
</html><?php /**PATH C:\xampp\htdocs\siaku\resources\views/latihan1.blade.php ENDPATH**/ ?>
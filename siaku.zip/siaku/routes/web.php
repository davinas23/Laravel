<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\latihan1;
use App\Http\Controllers\HomeController;
use Monolog\Processor\HostnameProcessor;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/greeting', function () {
    return ('Hello Word');
});

Route::get('/sam', function () {
    return ('Salam');
});

Route::get('/salam', function () {
    return ('Assalamualaikum');
});

Route::get('/biodata', function () {
    return View('latihan1', 
    	['name' => 'Davina', 
    	'kelas' => 'IK19B',
    	'umur' => '19tahun',
    	'hobi' => 'Membaca Novel',
    	'posisi' => 'Direktur',
    	'instansi' => 'PT OTW Kaya',
    	'negara' => 'Indonesia',
    	'agama' => 'Islam',
    	'pt' => 'PT Untung',
    	'ac' => 'PSPL']);
});

Route::get('/test1', [latihan1::class, 'biodata']);
// Route::get('\dashboard', [Dashboard::class, 'dashboard']);

//Post Controller
Route::get('/dashboard', [HomeController::class, 'index']);
